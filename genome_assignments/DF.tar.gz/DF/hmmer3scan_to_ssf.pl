#!/usr/bin/perl -w
use strict;

# Script to parse HMMScan output.
# It takes three arguments:
# (1) The hmmscan out file
# (2) Name of the ouput SSF file
# (3) Optional: a model to superfamily map file (i.e. "model_id,cath_code" CSV file)

# It parses out the match info & uses the alignment to split the match into segments
# Terminal segments of <4 residues are removed.

# Usage
if ((scalar (@ARGV) < 2) || (scalar @ARGV > 3)) {
	die "Usage: $0 <input file> <output file> <optional: map file>"
}

# Global vars
my $query_id = "";
my $GAP_THRESHOLD = 30;
my $MIN_TERMINAL_LENGTH = 4;
my $model;
my $domCount;
my $start = 10000000000;
my $stop = 0;
my $alignment = "";
my %evalues;
my %id_map;
my $use_cath_codes = 0;

# Begin
my $inputF = $ARGV[0];
my $ssfF = $ARGV[1];
my $mapF = $ARGV[2];


# Start by gathering the map together
if (defined $mapF) {
	%id_map = gather_map($mapF);
	$use_cath_codes = 1;
}

open INPUTFILE, "<$inputF" or die "Unable to read input file $inputF $!\n";
open SSF, ">$ssfF" or die "Unable to write SSF file: $!\n";

# Get the initial protein ID.
$query_id = &spool_header();

# Now, do some parsing. w00t.
while (my $line = <INPUTFILE>) {
	if ($line =~ m/^>>\s+(\S+)/) {
		# New model record, so process last match.
		if ($alignment ne "") {
			process_match($query_id, $model, $domCount,$start, $stop, $alignment, $evalues{$domCount});
		}
		$model = $1;
		$start = 10000000000;
		$stop = 0;
		$alignment = "";
		%evalues = ();
	} elsif ($line =~ m/^\s+(\d+)\s+\S+\s+\S+\s+\S+\s+\S+\s+(\S+)/) {
		$evalues{$1} = $2;
	} elsif ($line =~ m/^\s+==\s+domain\s+(\d+)\s+/) {
		# New match record, so process last match
		if ($alignment ne "") {
			process_match($query_id, $model, $domCount,$start, $stop, $alignment, $evalues{$domCount});
		}
		$domCount = $1;
		$start = 10000000000;
		$stop = 0;
		$alignment = "";
	} elsif ($line =~ m/^\s+(\S+)\s+(\d+)\s+(\S+)\s+(\d+)/) {
		next unless $1 eq $query_id;
		if ($2 < $start) {
			$start = $2;
		}

		if ( $4 > $stop) {
			$stop = $4;
		}

		$alignment .= $3;
	} elsif ($line =~ m/\/\//) {
		if ($alignment ne "") {
				process_match($query_id, $model, $domCount,$start, $stop, $alignment, $evalues{$domCount});
		}
		$query_id = &spool_header();
		$alignment = "";
	}
}

close SSF;
close INPUTFILE;

# Deals with the match and prints a bit of SSF format.
sub process_match {
	my $id = shift;
	my $mod = shift;
	my $dc = shift;
	my $qstart = shift;
	my $qstop = shift;
	my $qali = shift;
	my $evalue = shift;
	
	my @segments = @{process_alignment_string($qali,$qstart,$qstop)};

#    print STDERR "$model\n";

    &remove_terminal_short_segments(\@segments);

    if (scalar(@segments) > 0) {
	   my $seg_str = join ":", @segments;
	
	   my $dom_id;
	   if ($use_cath_codes) { $dom_id = $id_map{$mod}.'_'.$dc; }
	   else {$dom_id = $mod.'_'.$dc;}

	   print SSF "$id\t$dom_id\t0\t0\t0\t0\t0\t0\t0\t0\t$evalue\t0.00\t0.00\t", scalar(@segments),"\t$seg_str\n";
    }
}
sub remove_terminal_short_segments {
	my $segments_ar = shift;

    my $ar_length = scalar @{$segments_ar};
#        print STDERR "# SEGS: $ar_length\n";
	
	if ($ar_length != 1) {
#	    print STDERR "START\n";
    	my $n_segment = $segments_ar->[0];
	    my $n_length = &segment_length($n_segment);
#	    print STDERR "$n_segment, $n_length N\n";
		if ($n_length < $MIN_TERMINAL_LENGTH) {
#            print STDERR "Removing segment\n";
			shift @{$segments_ar};
		}
	
		my $c_segment = $segments_ar->[-1];
		my $c_length = &segment_length($c_segment);
#		print STDERR "$c_segment C $c_length\n";
		if ($c_length < $MIN_TERMINAL_LENGTH) {
#            print STDERR "Removing segment\n";
			pop @{$segments_ar};
		}
    }
}

sub segment_length {
	my $seg = shift;
#	print STDERR "$seg\n";
	my @coords = split ":", $seg;
	return $coords[1] - $coords[0] +1;
}

#sub join_segments {
#	my @ar = shift;
#	return join ":", @ar;
#}

sub process_alignment_string {
	my $align_str   = shift;
	my $match_start = shift;
	my $match_stop  = shift;

	my @segments;

	my @ali = split //, $align_str;

	my $res_counter = $match_start -
	  1;             # Initialise sequence position tracker at 1 residue before beginning of match
	my $gap_counter     = 0;    # Current gap length (insert or gap)
	my $gap_res_counter = 0;    # Counting insert residues in gap
	my $gap_open        = 0;    # Tracks whether a gap is currently open or not
	my $segment_start = $match_start; 

	# Step through the alignment residue-by-residue
	foreach my $aa (@ali) {
		$res_counter++; #  Move position in sequence forward one
		if ( $aa =~ m/^[a-z]$/) { # If an insert position ...
			if (! $gap_open)  {         # If the gap isn't open
				$gap_open = 1;			    # Open the gap.
				$gap_counter = 0;         # Reset the gap counter for a new gap
				$gap_res_counter = 0;  # Reset the gap residue counter as well
			}
			$gap_counter++;             # Add one to the gap length
			$gap_res_counter++;      # Add one to the number of residues in the gap
		} elsif ($aa eq '-') {
			$res_counter--;
		} elsif ($aa eq '.') {
			$res_counter--;
		} else {                          # If a standard aligned position ....
			if ($gap_open) {          # If a gap IS open ...
				$gap_open = 0;           # Close the gap
				if ($gap_counter > $GAP_THRESHOLD) {  # If closing gap is longer than threshold ...
					my $end = $res_counter - $gap_res_counter - 1; # Calculate the segment end
					push @segments, $segment_start.':'.$end;    # Create the segment
					$segment_start = $res_counter;    # Initialise the start of the new segment
				}
			}
		}
	}
	
	# Add final (or only segment)
	my $segment = $segment_start . ':' . $res_counter;
	push @segments, $segment;

	return \@segments;

}


# Spools through the record header until it finds the next sequence ID.
sub spool_header {
	my $current_id;
	# Spool to the end of the header
	while (my $line = <INPUTFILE>) {
		if ($line =~ m/^Query:\s+(\S+)/) {
			$current_id = $1;
			last;
		}
	}

	# SPOOL to the alignments
	while (my $line = <INPUTFILE>) {
		if ($line =~ m/Domain\s/) {
			last;
		}
	}
	return $current_id;
}


# Reads the Model->Superfamily Map from file
# and returns as a hash.
sub gather_map {
	my $file = shift;
	my %hash;
	open MAPFILE, "<$file" or die "Could not read the map file $file: $!\n";
	while (my $line = <MAPFILE>) {
		chomp($line);
		my ($dom_id,$cath_code) = split /,/, $line;
		$hash{$dom_id} = $cath_code;
	}
	close MAPFILE;
	return %hash;
}
